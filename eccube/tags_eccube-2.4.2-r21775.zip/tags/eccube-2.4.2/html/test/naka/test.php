<?php
	require_once("../../require.php");
	$path = MODULE2_PATH . "mdl_speedmail/config.php";
	include($path);
?>