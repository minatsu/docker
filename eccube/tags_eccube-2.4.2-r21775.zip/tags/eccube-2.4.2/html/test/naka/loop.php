<?php
    require_once("../../require.php");
    for($i = 0; $i < 180; $i++) {
        sleep(10);
        gfDebugLog("test$i");
    }

?>