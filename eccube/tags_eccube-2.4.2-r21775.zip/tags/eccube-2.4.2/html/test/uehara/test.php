<?php

test('???潟??);

function test($echo) {
	echo $echo;
}


?>