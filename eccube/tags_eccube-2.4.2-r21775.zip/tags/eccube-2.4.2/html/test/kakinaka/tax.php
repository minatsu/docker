<?php

require_once("../../require.php");


echo "四捨五入：" . sfRound(5.499599,5) . "<br>";


?>
