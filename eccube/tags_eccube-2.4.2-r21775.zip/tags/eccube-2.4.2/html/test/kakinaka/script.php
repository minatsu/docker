<?php

require_once("../../require.php");

$objView = new SC_UserView("./templates/");

//sfprintr($_SERVER);

$objView->display("script.tpl")


?>
