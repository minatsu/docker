<?php
require_once("../../require.php");

$test = "-1a";

$val = sfIsInt($test);

print($val);


?>