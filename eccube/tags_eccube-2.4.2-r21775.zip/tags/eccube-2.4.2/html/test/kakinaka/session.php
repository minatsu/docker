<?php

require_once("../../require.php");

$objSiteSess = new SC_SiteSession();
$objCartSess = new SC_CartSession();

sfprintr($_SESSION);

?>
