<?php
/** HTMLディレクトリからのDATAディレクトリの相対パス */
define("HTML2DATA_DIR", "/../data/");

/** DATA ディレクトリから HTML ディレクトリの相対パス */
define("DATA_DIR2HTML", "/../html/");

/*
 * Local variables:
 * coding: utf-8
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * End:
 */
?>
