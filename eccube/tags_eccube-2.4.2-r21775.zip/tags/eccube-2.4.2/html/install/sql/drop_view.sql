DROP VIEW vw_category_count;
DROP VIEW vw_product_class;
DROP VIEW vw_products_allclass_detail;
DROP VIEW vw_products_allclass;
DROP VIEW vw_products_nonclass;
DROP VIEW vw_cross_products_class;
DROP VIEW vw_cross_class;